// apps/menyra-restaurants/guest/detajet/detajet.js
import { bootCommon, initDetajet } from "../_shared/guest-core.js";

bootCommon();
initDetajet();
