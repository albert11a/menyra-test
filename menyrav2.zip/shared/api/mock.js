// STEP 001 Placeholder — Mock data
