# README_MENYRA (Placeholder)

STEP 001 = nur UI Platzhalter.
