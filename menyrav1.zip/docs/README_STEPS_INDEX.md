# README — STEPS INDEX

- STEP 001: Platzhalter-UI → docs/README_STEP_001_PLACEHOLDERS.md
- STEP 002: Admin-Design (MENYRA Dashboard UI) → docs/README_STEP_002_ADMIN_DESIGN.md
- STEP 004: UI Inventar + Karte Cleanup → docs/README_STEP_004_UI_INVENTAR.md
- STEP 005: Main Pages + Owner Admin Bereiche (Platzhalter) → docs/README_STEP_005_ALL_PLACEHOLDERS.md
