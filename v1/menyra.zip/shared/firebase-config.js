// STEP 001 Placeholder — Firebase config kommt später
