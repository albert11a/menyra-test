// =========================================================
// MENYRA — Bunny Edge Script Base
// Change this URL if you create a new Bunny Edge Script.
// =========================================================

export const BUNNY_EDGE_BASE = "https://menyra-edge-v2-q15e1.bunny.run";
