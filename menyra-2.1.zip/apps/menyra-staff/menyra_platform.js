import { bootPlatformAdmin } from "../menyra-restaurants/_shared/admin/platform-admin-core.js";
bootPlatformAdmin({ role: "staff", roleLabel: "Staff Platform" });
