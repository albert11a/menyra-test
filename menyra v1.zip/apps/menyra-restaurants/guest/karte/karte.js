// apps/menyra-restaurants/guest/karte/karte.js
import { bootCommon, initKarte } from "../_shared/guest-core.js";

bootCommon();
initKarte();
