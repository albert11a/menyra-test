// apps/menyra-restaurants/guest/porosia/porosia.js
import { bootCommon, initPorosia } from "../_shared/guest-core.js";

bootCommon();
initPorosia();
