import { bootPlatformAdmin } from "../menyra-restaurants/_shared/admin/platform-admin-core.js";
bootPlatformAdmin({ role: "ceo", roleLabel: "CEO Platform" });
