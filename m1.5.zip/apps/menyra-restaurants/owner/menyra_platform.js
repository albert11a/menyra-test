import { bootPlatformAdmin } from "../_shared/admin/platform-admin-core.js";
bootPlatformAdmin({ role: "owner", roleLabel: "Owner Admin" });
